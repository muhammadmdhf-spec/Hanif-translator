# Hanif Translator

Cara bikin APK lewat GitHub (tanpa Android Studio):

1. Buat repository baru di github.com (New repository).
2. Upload SEMUA isi folder ini (hasil ekstrak zip, bukan file zip-nya).
   Pastikan folder `.github` ikut ter-upload. Kalau tidak ikut:
   Add file > Create new file > ketik nama `.github/workflows/build.yml` > paste isi file itu.
3. Buka tab **Actions**. Build jalan otomatis setelah upload.
   Kalau tidak, pilih **Build APK** > **Run workflow**.
4. Tunggu sekitar 5-10 menit sampai centang hijau.
5. Klik run tersebut > bagian **Artifacts** > download **HanifTranslator-debug-apk**.
6. Ekstrak zip-nya, install `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal").
7. Kalau build merah: buka run > klik step yang gagal > salin pesan error ke Claude.
