package com.hanif.translator

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", r.resultCode).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(label(getString(R.string.app_name), 28f))
        root.addM(label(getString(R.string.tagline), 15f, C.GRAY))
        root.addM(button(getString(R.string.start), C.GREEN) { start() }, 32)
        root.addM(button(getString(R.string.languages), C.GRAY) { startActivity(Intent(this, LanguagesActivity::class.java)) })
        root.addM(button(getString(R.string.stop), C.RED) { stopService(Intent(this, OverlayService::class.java)) })
        setContentView(root); root.applyInsets()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (!Prefs.sp(this).getBoolean("asked", false)) {
            Prefs.sp(this).edit().putBoolean("asked", true).apply()
            AlertDialog.Builder(this).setTitle(R.string.core_title).setMessage(R.string.core_msg)
                .setPositiveButton(R.string.yes) { _, _ ->
                    CORE.forEach { Models.download(it) {} }
                    Toast.makeText(this, R.string.downloading, Toast.LENGTH_LONG).show()
                }
                .setNegativeButton(R.string.skip, null).show()
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_perm, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        projection.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
    }
}
