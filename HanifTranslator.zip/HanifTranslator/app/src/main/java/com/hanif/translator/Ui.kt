package com.hanif.translator

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val CORE = listOf("id", "ar", "zh", "en")

object C {
    val BG = Color.parseColor("#000000")
    val FG = Color.parseColor("#FFFFFF")
    val GREEN = Color.parseColor("#10B981")
    val GRAY = Color.parseColor("#64748B")
    val RED = Color.parseColor("#EF4444")
}

object Prefs {
    fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun src(c: Context) = sp(c).getString("src", "en")!!
    fun dst(c: Context) = sp(c).getString("dst", "id")!!
    fun save(c: Context, s: String, d: String) = sp(c).edit().putString("src", s).putString("dst", d).apply()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.shape(fill: Int, radiusDp: Int = 8, stroke: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
    setColor(fill); cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
}

fun Context.label(text: String, size: Float = 14f, color: Int = C.FG) =
    TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

fun Context.button(text: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
    this.text = text; textSize = 14f; setTextColor(C.FG); gravity = Gravity.CENTER
    setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(bg); setOnClickListener { onClick() }
}

fun Context.circleBtn(text: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
    this.text = text; textSize = 15f; setTextColor(C.FG); gravity = Gravity.CENTER
    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
    setOnClickListener { onClick() }
}

fun LinearLayout.addM(v: View, top: Int = 12) =
    addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = context.dp(top) })

fun View.applyInsets() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, i ->
        val b = i.getInsets(WindowInsetsCompat.Type.systemBars())
        val p = v.context.dp(16)
        v.setPadding(b.left + p, b.top + p, b.right + p, b.bottom + p); i
    }
}

fun langName(code: String): String =
    Locale.forLanguageTag(code).getDisplayName(Locale.getDefault()).replaceFirstChar { it.uppercase() }
