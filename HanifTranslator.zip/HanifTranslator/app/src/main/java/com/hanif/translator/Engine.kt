package com.hanif.translator

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizerOptionsInterface
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** OCR + translation. Translators auto-unload after 5 idle minutes. */
object Engine {
    private val h = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, Translator>()
    private val idle = Runnable { cache.values.forEach { it.close() }; cache.clear() }

    fun recognize(bmp: Bitmap, src: String, cb: (String?) -> Unit) {
        val o: TextRecognizerOptionsInterface = when (src) {
            "zh" -> ChineseTextRecognizerOptions.Builder().build()
            "ja" -> JapaneseTextRecognizerOptions.Builder().build()
            "ko" -> KoreanTextRecognizerOptions.Builder().build()
            "hi", "mr", "ne", "sa" -> DevanagariTextRecognizerOptions.Builder().build()
            else -> TextRecognizerOptions.DEFAULT_OPTIONS   // Latin (Arabic/Thai: not supported by ML Kit OCR)
        }
        val rec = TextRecognition.getClient(o)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { cb(it.text) }
            .addOnFailureListener { cb(null) }
            .addOnCompleteListener { rec.close() }
    }

    fun translate(text: String, src: String, dst: String, cb: (String?) -> Unit) {
        if (src == dst) return cb(text)
        h.removeCallbacks(idle)
        val t = cache.getOrPut("$src>$dst") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
        }
        t.downloadModelIfNeeded()
            .addOnSuccessListener { t.translate(text).addOnSuccessListener { cb(it) }.addOnFailureListener { cb(null) } }
            .addOnFailureListener { cb(null) }
        h.postDelayed(idle, 5 * 60_000L)
    }
}

object Models {
    private val mgr get() = RemoteModelManager.getInstance()
    private fun m(code: String) = TranslateRemoteModel.Builder(code).build()

    fun downloaded(cb: (Set<String>) -> Unit) {
        mgr.getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { s -> cb(s.map { it.language }.toSet()) }
            .addOnFailureListener { cb(emptySet()) }
    }
    fun download(code: String, cb: (Boolean) -> Unit) {
        mgr.download(m(code), DownloadConditions.Builder().build())
            .addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }
    fun delete(code: String, cb: (Boolean) -> Unit) {
        mgr.deleteDownloadedModel(m(code)).addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }
}
