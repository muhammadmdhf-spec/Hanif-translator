package com.hanif.translator

import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Full-screen dim layer with a movable / resizable / pinch-zoomable scan box. */
class SelectionView(
    ctx: Context, start: RectF,
    private val onScan: (RectF) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {
    private val box = RectF(start)
    private val dim = Paint().apply { color = Color.parseColor("#99000000") }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.GREEN; style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.GREEN }
    private val hr = ctx.dp(16).toFloat()
    private val minSz = ctx.dp(48).toFloat()
    private var mode = 0 // 1 draw, 2 move, 3 resize
    private var moved = false
    private var ax = 0f; private var ay = 0f; private var lx = 0f; private var ly = 0f
    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { scaleBox(d.scaleFactor); return true }
    })

    init {
        setWillNotDraw(false)
        val bar = LinearLayout(ctx)
        fun add(t: String, bg: Int, f: () -> Unit) = bar.addView(ctx.button(t, bg, f),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = ctx.dp(6); marginEnd = ctx.dp(6) })
        add("−", C.GRAY) { scaleBox(0.8f) }
        add("+", C.GRAY) { scaleBox(1.25f) }
        add("✓", C.GREEN) { onScan(RectF(box)) }
        add("✖", C.RED) { onCancel() }
        addView(bar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ctx.dp(56) })
    }

    private fun scaleBox(f: Float) {
        val cx = box.centerX(); val cy = box.centerY()
        val w = max(minSz, box.width() * f); val h = max(minSz, box.height() * f)
        box.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2); invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, box.top, dim); c.drawRect(0f, box.bottom, w, h, dim)
        c.drawRect(0f, box.top, box.left, box.bottom, dim); c.drawRect(box.right, box.top, w, box.bottom, dim)
        c.drawRect(box, line); c.drawCircle(box.right, box.bottom, hr, dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (sd.isInProgress) { mode = 0; return true }
        if (e.pointerCount > 1) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y; moved = false
                mode = when {
                    hypot(e.x - box.right, e.y - box.bottom) < hr * 2 -> 3
                    box.contains(e.x, e.y) -> 2
                    else -> { ax = e.x; ay = e.y; 1 }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.x - lx, e.y - ly) > 2f) moved = true
                when (mode) {
                    1 -> box.set(min(ax, e.x), min(ay, e.y), max(ax, e.x), max(ay, e.y))
                    2 -> box.offset(e.x - lx, e.y - ly)
                    3 -> { box.right = max(box.left + minSz, e.x); box.bottom = max(box.top + minSz, e.y) }
                }
                lx = e.x; ly = e.y; invalidate()
            }
            MotionEvent.ACTION_UP -> {
                // Drawing a fresh box and releasing = scan immediately
                if (mode == 1 && moved && box.width() > minSz / 2 && box.height() > minSz / 2) onScan(RectF(box))
                mode = 0
            }
        }
        return true
    }
}
